import SwiftUI

//MARK: MODEL VIEW

class HotelType : ObservableObject{
    @Published var hotelList : [Hotels] = []
    
}


